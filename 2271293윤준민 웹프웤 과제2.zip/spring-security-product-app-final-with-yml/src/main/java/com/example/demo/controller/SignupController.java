package com.example.demo.controller;

import com.example.demo.dto.SignupRequest;
import com.example.demo.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class SignupController {
    private final UserService userService;

    @GetMapping("/signup")
    public String signupForm(Model model) {
        model.addAttribute("user", new SignupRequest());
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@Valid @ModelAttribute("user") SignupRequest request,
                         BindingResult result,
                         Model model) {
        if (result.hasErrors()) return "signup";

        try {
            userService.register(request);
        } catch (IllegalArgumentException e) {
            model.addAttribute("customError", e.getMessage());
            return "signup";
        }

        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";  // ⭐ 이거 추가하면 login.html 페이지가 뜸
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }
}
